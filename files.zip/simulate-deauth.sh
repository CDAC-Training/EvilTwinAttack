#!/usr/bin/env bash
# Simulated deauthentication step for the Evil Twin lab.
#
# WHY THIS IS A SIMULATION, NOT A REAL INJECTION:
# A real evil-twin deauth attack injects spoofed 802.11 deauth frames from a
# monitor-mode radio impersonating the AP's BSSID. That requires (a) a spare
# radio free to enter monitor mode - this topology commits all three radios to
# fixed roles (corp AP, evil-twin AP, victim client), none free - and (b)
# wmediumd to carry injected frames between network namespaces. wmediumd is
# NOT running on these VMs, so an injected frame would not reach the victim.
#
# We therefore reproduce the *effect* the attack produces - the victim being
# knocked off the legitimate AP and NOT automatically returning to it - rather
# than the injection mechanism itself. mac80211 still emits a genuine
# deauthentication management frame (type 0 / subtype 0x0c) on the victim's
# radio as it leaves, so a real deauth frame is still present in victim.pcap
# for the Part 7 analysis. The distinction from a real attack (this frame is
# station-initiated, not attacker-spoofed) is itself a teaching point - see the
# lab manual Part 5 note.
set -euo pipefail

NS="ns-victim"
IFACE="wlan0"

if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (once per boot)." >&2
    exit 1
fi

echo "[*] Victim association BEFORE simulated deauth:"
ip netns exec "$NS" iw dev "$IFACE" link || true
echo

echo "[*] Simulating deauthentication burst against the victim..."
# wpa_supplicant is what holds the victim on the WPA2 corp AP; stopping it
# prevents an automatic re-association so the disconnect is observable.
pkill -f "wpa_supplicant" 2>/dev/null || true
ip netns exec "$NS" iw dev "$IFACE" disconnect 2>/dev/null || true
sleep 1

echo
echo "[*] Victim association AFTER simulated deauth:"
ip netns exec "$NS" iw dev "$IFACE" link || true
echo
echo "[*] Victim is disconnected and will NOT auto-reconnect."
echo "    Proceed to the reassociation step in the manual and observe which"
echo "    AP it lands on when you point it back at 'CorpNet-Secure'."
