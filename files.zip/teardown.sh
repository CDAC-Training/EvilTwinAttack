#!/usr/bin/env bash
set -euo pipefail
# --- FIX: also stop wpa_supplicant (victim's WPA2 client) and the php captive
# portal started by start-evil-twin.sh, not just hostapd/dnsmasq.
for p in hostapd dnsmasq wpa_supplicant "php -S"; do pkill -f "$p" 2>/dev/null || true; done
for ns in ns-corp ns-eviltwin ns-victim; do
    ip netns del "$ns" 2>/dev/null || true
done
echo "[*] Torn down. Reload kernel module or re-run setup-netns.sh to restart."
