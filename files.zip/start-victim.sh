#!/usr/bin/env bash
set -e
# --- FIX: setup-netns.sh now renames every namespace's radio to this
# canonical name, so we no longer assume ns-victim specifically got the
# original "wlan2" (it might have gotten wlan0 or wlan1 depending on phy
# enumeration order at boot).
IFACE="wlan0"
NS="ns-victim"

# --- FIX: namespaces do not persist across reboots and are only created by
# setup-netns.sh, which must run before this script every boot. Running out
# of order previously failed with a bare "Cannot find device wlan0" - fail
# fast here with a message that says what to actually do about it.
if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (it must run once per boot before any start-*.sh script)." >&2
    exit 1
fi

ip netns exec ns-victim ip link set "$IFACE" up
echo "$IFACE is up in ns-victim. Use: sudo ip netns exec ns-victim iw dev $IFACE scan"
