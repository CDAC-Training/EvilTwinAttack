# Evil Twin Lab — Golden Image Build & Deployment Guide

This guide builds the Kali golden image, converts it to a Proxmox template, and
deploys 25 student clones. Do the steps in order. Every command runs as `root`
unless noted. Reserve ~45–60 minutes plus package-download time.

The build scripts are idempotent — re-running `01`/`02`/`03_configure_xrdp`
after a transient failure is safe.

---

## 0. Prerequisites and one-time inputs

**On the Proxmox host:**

- A three-node Proxmox/Ceph cluster (or any Proxmox host) with an internet
  bridge, the host-only management bridge `vmbr98`, and the campus bridge
  `vmbr0` all present.
- `vmbr98`'s `dnsmasq` pool narrowed so it does **not** overlap the static
  student range `10.99.99.101–.125`. Recommended:
  ```
  # /etc/dnsmasq.d/vmbr98-lab-mgmt.conf
  dhcp-range=10.99.99.150,10.99.99.200,255.255.255.0,12h
  ```
  then `systemctl restart dnsmasq`. `deploy-clones.sh` refuses to run until
  this is done.

**Campus network values you must confirm before building** (edit
`01_golden_kali_setup.sh` §0):

| Variable | Placeholder | Confirm with campus networking |
|---|---|---|
| `CAMPUS_NET_PREFIX` | `140.158.130` | the /24 the student VMs live on |
| `CAMPUS_PREFIX_LEN` | `24` | netmask length |
| `CAMPUS_GATEWAY` | `140.158.130.1` | real gateway; must **not** be in `.1–.25` |
| `CAMPUS_DNS_1/2` | `140.158.128.1/.2` | ns1/ns2 |

> **Reserve `140.158.130.1`–`.25` with campus IPAM** so they don't collide with
> existing hosts (the `cs.lamar.edu` zone already uses e.g. `140.158.130.72`).
>
> **Security:** these clones use `studentNN`/`studentNN` sudo accounts. On a
> routable campus address that is a real exposure. Put a firewall ACL in front
> of `140.158.130.0/24` limiting inbound RDP/SSH to classroom source ranges,
> and/or move to SSH keys or stronger passwords, before the campus path is live.

---

## 1. Create the build VM (VMID 1000)

1. Create a new Kali Linux VM, VMID `1000`, name `kali-golden`. Give it a
   generous disk (≥40 GB), 2+ vCPU, 4+ GB RAM.
2. Attach the **internet** bridge as `net0` for the build (the campus bridge
   `vmbr0` provides this if it routes to the internet). The clones' NIC layout
   is assigned later by `deploy-clones.sh`; during the build you only need
   working internet.
3. Install Kali normally, enable SSH, and boot it.

> Rebuilding a future semester's template? Don't edit the template's VMID in
> place. `qm clone <template> <new_vmid> --full true`, reattach internet, and
> run these scripts on the full clone, then re-template that clone.

---

## 2. Copy the lab scripts onto the build VM

Copy all of these into `/root/eviltwin-build/` on `kali-golden`:

- `01_golden_kali_setup.sh`
- `02_generalize_for_cloning.sh`
- `03_configure_xrdp.sh`

`deploy-clones.sh` runs on the **Proxmox host**, not the build VM — keep it there.

```bash
mkdir -p /root/eviltwin-build && cd /root/eviltwin-build
# scp the three scripts here, then:
chmod +x 01_golden_kali_setup.sh 02_generalize_for_cloning.sh 03_configure_xrdp.sh
```

---

## 3. Set the campus parameters

Edit `01_golden_kali_setup.sh` and set the §0 `CAMPUS_*` variables to the
confirmed values from step 0. Double-check `CAMPUS_GATEWAY` is outside `.1–.25`.

---

## 4. Run the golden setup script

```bash
./01_golden_kali_setup.sh
```

This installs the lab tooling (`hostapd`, `dnsmasq`, `aircrack-ng`, capture
tools, etc.), loads `mac80211_hwsim radios=3`, writes all lab scripts and
configs under `/opt/eviltwin-lab/`, and lays down the `eth0` (host-only) and
`eth1` (campus) systemd-networkd templates.

**Verify before continuing:**

```bash
# Three virtual radios present:
iw dev | awk '/Interface/{print $2}'          # expect wlan0 wlan1 wlan2

# Both eviltwin configs bind to wlan0 (not wlan1):
grep -H '^interface=' /opt/eviltwin-lab/configs/hostapd-corp.conf \
                       /opt/eviltwin-lab/configs/hostapd-eviltwin.conf \
                       /opt/eviltwin-lab/configs/dnsmasq-eviltwin.conf

# Campus template rendered with your real gateway/DNS:
cat /etc/systemd/network/20-eth1.network.template
```

Optionally smoke-test the lab end-to-end now (see step 8's checklist) before
generalizing — it's easier to fix on the build VM than on 25 clones.

---

## 5. Configure xrdp (GUI access)

```bash
./03_configure_xrdp.sh
```

This applies the final working xrdp/XFCE configuration (system-level session
wiring, `KillDisconnected=true`, `SaveOnExit=false`, and removal of the
`.xsession`/`.xsessionrc`/`.xinitrc`/stale-cache artifacts from root, all
homes, and `/etc/skel`). It self-verifies and exits non-zero if anything is
unclean. Run it **before** step 6.

---

## 6. Generalize for cloning

```bash
./02_generalize_for_cloning.sh
```

This strips machine-id, hostname, SSH host keys, and NetworkManager/lease
state, and installs the `eviltwin-firstboot.service` that assigns each clone
its identity, `eth0` management IP, and `eth1` campus IP on first boot.

> **Do not reboot the build VM after this step.** A reboot re-commits
> machine-id/hostname state that every clone would then inherit. Shut it down
> directly.

```bash
shutdown -h now
```

---

## 7. Convert to a template (on the Proxmox host)

```bash
# Detach the build-time internet NIC if you want a clean template, then:
qm template 1000
```

---

## 8. Deploy the student clones (on the Proxmox host)

Point `deploy-clones.sh` at the template (`TEMPLATE_VMID=1000`) and set the
roster size if it isn't 25 (`STUDENT_COUNT=25`). Then:

```bash
./deploy-clones.sh
# or a different size: STUDENT_COUNT=20 ./deploy-clones.sh
```

It clones VMIDs `9101`–`9125`, injects each clone's student number via the
SMBIOS serial, attaches `net0=vmbr98` and `net1=vmbr0`, starts them, and waits
for `eviltwin-firstboot.service` to finish (clones answer on `10.99.99.1NN`).

**Per-clone smoke test** (pick one clone, e.g. via the Proxmox console or
`ssh studentNN@140.158.130.NN`):

```bash
# Identity + both addresses
hostnamectl                                   # kali-student-NN
ip -4 addr show eth0                           # 10.99.99.1NN
ip -4 addr show eth1                           # 140.158.130.NN
ip route                                       # default via campus gateway

# Lab brings up cleanly
sudo /opt/eviltwin-lab/scripts/setup-netns.sh
sudo /opt/eviltwin-lab/scripts/start-corp-ap.sh
sudo ip netns exec ns-corp iw dev wlan0 info | grep -E 'type|ssid'   # type AP / CorpNet-Secure
sudo /opt/eviltwin-lab/scripts/start-evil-twin.sh
sudo ip netns exec ns-eviltwin iw dev wlan0 info | grep -E 'type|ssid'  # type AP / CorpNet-Secure
sudo /opt/eviltwin-lab/scripts/teardown.sh
```

---

## 9. Snapshot and provision access

1. Snapshot each clone at its clean state:
   ```bash
   for v in $(seq 9101 9125); do qm snapshot "$v" clean-start; done
   ```
2. Create the 25 Guacamole connection profiles (RDP, port 3389, target the
   `10.99.99.1NN` management address, username/password `studentNN`). See the
   instructor manual §9 for the full mapping and the Guacamole field settings.
3. Direct campus login needs no per-VM provisioning — students RDP/SSH to
   `140.158.130.NN` once the ACL and IP reservations are in place.

---

## 10. Rebuild checklist for future semesters

1. `qm clone <template> <new_vmid> --full true`; attach internet; boot.
2. Re-run steps 3–7 on the full clone.
3. Repoint `deploy-clones.sh` `TEMPLATE_VMID` at the new template; redeploy.
4. Destroy the old clones and old template once a throwaway test clone from the
   new template passes the step-8 smoke test.
