#!/usr/bin/env bash
###############################################################################
# Run ONCE on the golden Kali VM, immediately before converting it to a
# Proxmox template ("qm template <vmid>"). This strips machine-specific
# state so that all N linked clones don't collide (duplicate SSH host
# keys, duplicate machine-id, duplicate hostname, stale hwsim MACs, stale
# NetworkManager/DHCP lease state).
#
# IMPORTANT: after this script finishes, shut the VM down directly and
# template it. Do NOT reboot it first — see explanation below.
###############################################################################
set -euo pipefail

echo "[*] Stopping lab services before generalization"
/opt/eviltwin-lab/scripts/teardown.sh || true
systemctl stop eviltwin-lab-netsetup.service 2>/dev/null || true

echo "[*] Clearing machine-id (regenerated on first boot of each clone)"
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id
ln -s /etc/machine-id /var/lib/dbus/machine-id

# --- FIX: /etc/hostname was never cleared, so even on the rare occasion the
# old firstboot service DID fire, `hostnamectl set-hostname` was overwriting
# a file that still held stale state from earlier boots of the golden image.
# More importantly: this line alone will NOT fix the "same hostname on every
# clone" bug by itself — see the ConditionFirstBoot fix below, which is the
# actual root cause.
echo "[*] Clearing hostname (set on first boot of each clone)"
truncate -s 0 /etc/hostname

# --- FIX: stale NetworkManager connection UUIDs and cached leases are
# baked into the golden image and are identical across all clones, which
# can cause D-Bus/NM conflicts and prevents the static eth0 config from
# taking effect cleanly.
echo "[*] Clearing NetworkManager and DHCP/networkd lease state"
rm -f /etc/NetworkManager/system-connections/*.nmconnection 2>/dev/null || true
rm -rf /var/lib/NetworkManager/*
rm -f /var/lib/dhcp/*.leases 2>/dev/null || true
rm -rf /var/lib/systemd/network/*.lease 2>/dev/null || true
rm -f /etc/systemd/network/10-eth0.network 2>/dev/null || true
rm -f /etc/systemd/network/20-eth1.network 2>/dev/null || true

echo "[*] Removing SSH host keys (regenerated on first boot)"
rm -f /etc/ssh/ssh_host_*

echo "[*] Installing regeneration + per-clone identity oneshot service"

# --- ROOT-CAUSE FIX ---
# The previous unit used `ConditionFirstBoot=yes`, which depends on systemd's
# global first-boot marker (/run/systemd/first-boot). That marker is only set
# when /etc/machine-id is empty at the moment PID1 starts. If the golden VM
# is rebooted even once after this script runs but before `qm template` is
# issued, systemd commits a real machine-id to disk on that reboot — which
# "uses up" the first-boot condition on the golden image itself. Every linked
# clone then inherits an already-populated machine-id, so
# ConditionFirstBoot=yes evaluates FALSE on every single clone, forever. This
# is consistent with the symptom you saw: identical hostname across all 25
# VMs, and none of the identity/IP logic ever running.
#
# The fix: use a stamp file that we own and control (/opt/eviltwin-lab/.firstboot-done),
# which is guaranteed absent on the golden image (we never create it here)
# and is only ever written by the script itself, per clone, on that clone's
# own copy-on-write disk. This has no dependency on systemd's machine-id
# heuristics at all.
cat >/etc/systemd/system/eviltwin-firstboot.service <<'EOF'
[Unit]
Description=Evil Twin Lab: per-clone first boot identity setup
After=network-pre.target systemd-udevd.service systemd-modules-load.service
Before=network.target systemd-networkd.service NetworkManager.service sshd.service eviltwin-lab-netsetup.service
ConditionPathExists=!/opt/eviltwin-lab/.firstboot-done

[Service]
Type=oneshot
ExecStart=/opt/eviltwin-lab/scripts/firstboot-identity.sh
RemainAfterExit=yes
# --- FIX: hard safety net. Nothing in firstboot-identity.sh should ever take
# more than a few seconds, but this service is ordered Before=network.target
# and sshd.service -- if anything inside it ever stalls (a debconf prompt,
# an entropy read, whatever), it would otherwise hang the ENTIRE boot
# indefinitely with no way to recover except a forced VM reset. Bound it.
TimeoutStartSec=90

[Install]
WantedBy=multi-user.target
EOF

cat >/opt/eviltwin-lab/scripts/firstboot-identity.sh <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

# vmbr98 lab-management network: dnsmasq serves 10.99.99.100-10.99.99.200
# with no default gateway (dhcp-option=3 empty => host-only). Static clones
# use 10.99.99.101-10.99.99.125, i.e. ${ETH0_NET_PREFIX}.$((100+N)).
#
# WARNING: this static range currently sits INSIDE the dnsmasq dhcp-range on
# the Proxmox host. Narrow that pool (e.g. to 10.99.99.150,10.99.99.200) so
# it can never hand out an address a static clone is also using.
ETH0_NET_PREFIX="10.99.99"

# Regenerate machine-id
systemd-machine-id-setup

# Regenerate SSH host keys
# --- FIX: dpkg-reconfigure openssh-server goes through debconf, which is a
# less deterministic path than needed here and a plausible boot-hang source
# inside a service ordered Before=sshd.service/network.target. ssh-keygen -A
# does the exact same job (regenerates any missing host keys) directly.
ssh-keygen -A

# --- FIX: student number is now read from the SMBIOS serial field, which
# deploy-clones.sh sets explicitly and deterministically per VM (base64 of
# the loop index, e.g. "07"), instead of the tail of the SMBIOS UUID (which
# is stable per-VM but random, unpredictable, and not tied to the intended
# "kali-student-NN" numbering scheme).
RAW_SERIAL="$(dmidecode -s system-serial-number 2>/dev/null || true)"

# --- FIX: validate RAW_SERIAL is actually well-formed base64 BEFORE decoding.
# Garbage input (e.g. Proxmox's default "Not Specified" placeholder, or any
# manually-cloned VM that never got -smbios1 set) does not reliably fail
# base64 -d — GNU base64 can emit partial decoded bytes before erroring, and
# `tr -cd 0-9` can turn those stray bytes into a plausible-looking digit
# instead of an empty string. That silently produces a wrong-but-valid-seeming
# STUDENT_NUM and skips the intended fallback/warning path entirely. Require
# the raw string to be pure base64 alphabet (with correct padding) first.
if printf '%s' "$RAW_SERIAL" | grep -qE '^[A-Za-z0-9+/]*={0,2}$' && [ -n "$RAW_SERIAL" ]; then
    STUDENT_NUM="$(printf '%s' "$RAW_SERIAL" | base64 -d 2>/dev/null | tr -cd '0-9' || true)"
else
    STUDENT_NUM=""
fi

if [ -z "$STUDENT_NUM" ]; then
    # Fallback if SMBIOS serial wasn't set (e.g. VM cloned by hand) — derive
    # something unique from the SMBIOS UUID tail so the VM is at least usable,
    # but flag it clearly since numbering won't match the class roster.
    UUID_TAIL=$(dmidecode -s system-uuid 2>/dev/null | tail -c 5 | tr -cd '0-9')
    STUDENT_NUM="${UUID_TAIL:-99}"
    logger -t eviltwin-firstboot "WARNING: no SMBIOS serial found; falling back to UUID-derived id ${STUDENT_NUM}"
fi

STUDENT_NUM_INT=$((10#$STUDENT_NUM))
STUDENT_NUM_PAD=$(printf '%02d' "$STUDENT_NUM_INT")

# Hostname
NEWHOST="kali-student-${STUDENT_NUM_PAD}"
hostnamectl set-hostname "$NEWHOST"
echo "127.0.1.1 $NEWHOST" >> /etc/hosts

# --- Per-clone student account with sudo privileges ---
# studentNN matches the hostname suffix (kali-student-01 -> student01, etc).
STUDENT_USER="student${STUDENT_NUM_PAD}"
if ! id "$STUDENT_USER" &>/dev/null; then
    useradd -m -s /bin/bash -c "Lab account for ${NEWHOST}" "$STUDENT_USER"
    usermod -aG sudo "$STUDENT_USER"

    # --- CHANGED: password intentionally matches the username for
    # classroom convenience (student07 / student07, etc.) rather than a
    # random generated one. This is a deliberate simplicity/security
    # tradeoff the instructor has chosen -- acceptable here because these
    # VMs sit on vmbr98, a host-only management network with no route out
    # and no exposure beyond the isolated lab. Do not reuse this pattern
    # for anything that isn't fully isolated like this one is.
    STUDENT_PASS="$STUDENT_USER"
    echo "${STUDENT_USER}:${STUDENT_PASS}" | chpasswd

    # Credential is recorded locally, root-only, for the instructor to hand
    # off (e.g. via `qm terminal <vmid>` or console) — never logged or echoed
    # to syslog/console in plaintext.
    umask 077
    printf '%s %s %s\n' "$NEWHOST" "$STUDENT_USER" "$STUDENT_PASS" >> /root/student-credentials.txt
    chmod 600 /root/student-credentials.txt

    # --- CHANGED: no forced password change on first login. That feature
    # only makes sense paired with a random one-time password; forcing a
    # change away from the intentionally-simple studentNN/studentNN
    # password would immediately defeat the point of using it. If you
    # later want to re-add this (e.g. for a real deployment with random
    # passwords), the line is: chage -d 0 "$STUDENT_USER"

    logger -t eviltwin-firstboot "Created sudo account ${STUDENT_USER} on ${NEWHOST}"
fi

# --- FIX: static IP for eth0 (vmbr98), previously never configured at all.
# No gateway/DNS: vmbr98 is host-only per the dnsmasq config (dhcp-option=3 empty).
STATIC_IP="${ETH0_NET_PREFIX}.$((100 + STUDENT_NUM_INT))"
sed "s/__STATIC_IP__/${STATIC_IP}/" \
    /etc/systemd/network/10-eth0.network.template > /etc/systemd/network/10-eth0.network
logger -t eviltwin-firstboot "Assigned eth0 = ${STATIC_IP}/24 (host-only, no gateway) for ${NEWHOST}"

# --- eth1 campus static IP (vmbr0) so studentNN can RDP/SSH directly to
# kali-student-NN at <campus-prefix>.NN. The prefix/gateway/DNS/netmask are
# baked into the template by 01_golden_kali_setup.sh; here we only fill in
# this clone's host octet (STUDENT_NUM_INT, e.g. 7 -> ...130.7, 25 -> ...130.25).
if [ -f /etc/systemd/network/20-eth1.network.template ]; then
    sed "s/__NN__/${STUDENT_NUM_INT}/" \
        /etc/systemd/network/20-eth1.network.template > /etc/systemd/network/20-eth1.network
    logger -t eviltwin-firstboot "Rendered eth1 campus static IP for ${NEWHOST} (host octet ${STUDENT_NUM_INT})"
else
    logger -t eviltwin-firstboot "WARNING: 20-eth1.network.template missing; eth1 campus IP not configured"
fi

# Re-randomize hwsim virtual MACs so captures are visually distinguishable
# per student when instructor aggregates pcaps for grading.
#
# --- FIX: previously hardcoded to wlan0/wlan1/wlan2. This runs before
# setup-netns.sh has split the radios into namespaces, so they're still
# whatever the kernel named them - not guaranteed to be exactly those three.
# Discover them instead of assuming.
mapfile -t HWSIM_IFACES < <(iw dev 2>/dev/null | awk '/Interface/{print $2}')
for i in "${HWSIM_IFACES[@]}"; do
    macchanger -r "$i" || true
done

touch /opt/eviltwin-lab/.firstboot-done
SCRIPT
chmod +x /opt/eviltwin-lab/scripts/firstboot-identity.sh

systemctl enable eviltwin-firstboot.service

echo "[*] Clearing shell history and temp lab artifacts"
history -c || true
rm -f /root/.bash_history
rm -rf /opt/eviltwin-lab/logs/* /opt/eviltwin-lab/captures/*
rm -f /opt/eviltwin-lab/.firstboot-done   # ensure golden image itself is NOT marked done

echo "[*] Generalization complete."
echo "[*] Shut this VM down NOW (do not reboot it), then in Proxmox: qm template <vmid>"
echo "[*] Deploy with deploy-clones.sh, which sets the per-clone SMBIOS serial this"
echo "    script depends on for hostname/IP assignment."
