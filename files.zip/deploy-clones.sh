#!/bin/bash
###############################################################################
# deploy-clones.sh — deploy student Kali VMs from the eviltwin-lab template
###############################################################################
set -euo pipefail

# --- FIX: parameterized instead of hardcoded "25" scattered across five
# separate spots in the script. Future semesters with a different roster
# size only need to change this one line (or pass STUDENT_COUNT=N in the
# environment, e.g. `STUDENT_COUNT=20 ./deploy-clones.sh`).
STUDENT_COUNT="${STUDENT_COUNT:-25}"

TEMPLATE_VMID=1000
BASE_VMID=9100          # clones will be BASE_VMID+1 .. BASE_VMID+STUDENT_COUNT

# vmbr98 lab-management network — host-only, dnsmasq pool 10.99.99.100-.200,
# no default gateway (dhcp-option=3 empty). Static clones use
# .101-.1(00+STUDENT_COUNT), i.e. student N -> ${ETH0_NET_PREFIX}.$((100+N))
# (must match firstboot-identity.sh).
#
# WARNING: this static range sits inside the existing dnsmasq dhcp-range on
# the Proxmox host by default. Before deploying, narrow that pool, e.g.:
#   dhcp-range=10.99.99.150,10.99.99.200,255.255.255.0,12h
# otherwise dnsmasq can still hand a static clone's address to a DHCP
# client. The pre-flight check below enforces this automatically.
ETH0_NET_PREFIX="10.99.99"
# -----------------------------------------------------------------------

# --- FIX: bounds-check STUDENT_COUNT. The static-IP scheme uses
# 10.99.99.$((100+N)), which only stays inside a sane /24 range and inside
# the two-digit hostname padding (kali-student-NN) for N <= 99.
if [ "$STUDENT_COUNT" -lt 1 ] || [ "$STUDENT_COUNT" -gt 99 ]; then
    echo "ERROR: STUDENT_COUNT=${STUDENT_COUNT} is out of range (1-99)." >&2
    echo "       The static-IP/hostname scheme (10.99.99.1NN / kali-student-NN)" >&2
    echo "       assumes a two-digit student number." >&2
    exit 1
fi

# Actually verify the host's dnsmasq pool has been narrowed before
# deploying, instead of relying on someone remembering to do it by hand.
DNSMASQ_CONF="/etc/dnsmasq.d/vmbr98-lab-mgmt.conf"
if [ -f "$DNSMASQ_CONF" ] && grep -qE 'dhcp-range=10\.99\.99\.(10[0-9]|1[0-2][0-9])' "$DNSMASQ_CONF"; then
    echo "ERROR: ${DNSMASQ_CONF} still overlaps the static range 10.99.99.101-1$((100 + STUDENT_COUNT))." >&2
    echo "        Narrow it first, e.g.:" >&2
    echo "        dhcp-range=10.99.99.150,10.99.99.200,255.255.255.0,12h" >&2
    echo "        then: systemctl restart dnsmasq" >&2
    exit 1
fi

echo "[*] Deploying ${STUDENT_COUNT} student clones from template VMID ${TEMPLATE_VMID}"

for i in $(seq -w 1 "$STUDENT_COUNT"); do
    vmid=$((BASE_VMID + 10#${i}))   # 10# forces base-10 to avoid octal issues with 08, 09
    name="kali-student-${i}"

    echo "[*] Cloning VMID ${vmid} (${name})"
    qm clone "$TEMPLATE_VMID" "$vmid" --name "$name" --full false

    # This is the piece firstboot-identity.sh depends on entirely: without
    # it, the guest has no reliable, deterministic way to know which
    # student number it is. We pass the loop index in via the SMBIOS
    # "serial" field (base64-encoded, as Proxmox requires for arbitrary
    # string values), and the guest reads it back with:
    #   dmidecode -s system-serial-number | base64 -d
    serial_b64=$(printf '%s' "$i" | base64 -w0)
    qm set "$vmid" -smbios1 "serial=${serial_b64},base64=1"

    # net0 = vmbr98 (host-only management, eth0, static 10.99.99.1NN — Guacamole path)
    # net1 = vmbr0  (campus, eth1, static 140.158.130.NN — direct student RDP/SSH login)
    # vmbr99 (formerly an "isolated lab" bridge) is removed: all wireless is
    # simulated in-kernel via mac80211_hwsim inside namespaces and never touches
    # a Proxmox bridge, so vmbr99 carried nothing.
    echo "[*] Attaching vmbr98 (eth0, management/Guacamole) and vmbr0 (eth1, campus login)"
    qm set "$vmid" -net0 virtio,bridge=vmbr98,firewall=1
    qm set "$vmid" -net1 virtio,bridge=vmbr0,firewall=1

    echo "[*] Starting ${name}"
    qm start "$vmid"

    sleep 2   # stagger boots slightly so they don't all hit the hypervisor at once
done

LAST_VMID=$((BASE_VMID + STUDENT_COUNT))
echo "[*] Deployed ${STUDENT_COUNT} clones (VMIDs $((BASE_VMID + 1))-${LAST_VMID})."
echo "[*] Waiting for eviltwin-firstboot.service to finish on each (up to 3 min)..."

READY=0
for attempt in $(seq 1 18); do
    READY=0
    for n in $(seq 101 $((100 + STUDENT_COUNT))); do
        ping -c1 -W1 "${ETH0_NET_PREFIX}.${n}" >/dev/null 2>&1 && READY=$((READY + 1))
    done
    echo "    [$attempt/18] ${READY}/${STUDENT_COUNT} clones responding on vmbr98"
    [ "$READY" -eq "$STUDENT_COUNT" ] && break
    sleep 10
done

if [ "$READY" -lt "$STUDENT_COUNT" ]; then
    echo "WARNING: only ${READY}/${STUDENT_COUNT} clones came up on vmbr98. Check the missing ones via" >&2
    echo "         the Proxmox console: hostnamectl ; ip -4 addr show eth0 ; journalctl -u eviltwin-firstboot.service" >&2
else
    echo "[*] All ${STUDENT_COUNT} clones are up."
fi

echo ""
echo "[*] Each clone has a sudo-enabled account studentNN with password"
echo "    studentNN (matching the username, e.g. student07 / student07)."
echo "    No forced password change -- students can log in immediately."
echo "    Tell students the pattern directly; there is nothing to retrieve"
echo "    per-VM from /root/student-credentials.txt for this deployment."
echo ""
echo "[*] Access paths per clone:"
echo "    - Guacamole (browser)  -> via eth0 10.99.99.1NN (host-only vmbr98)"
echo "    - Direct RDP/SSH        -> via eth1 140.158.130.NN (campus vmbr0)"
echo "      e.g. student07 -> kali-student-07 at 140.158.130.7"
echo ""
echo "[!] SECURITY: eth1 puts each VM on a routable campus address with a"
echo "    studentNN/studentNN sudo account. Ensure a campus firewall ACL limits"
echo "    inbound RDP/SSH to 140.158.130.0/24 to classroom source ranges, and/or"
echo "    move to SSH keys or stronger passwords, before relying on this path."
