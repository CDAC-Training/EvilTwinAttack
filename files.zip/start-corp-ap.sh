#!/usr/bin/env bash
set -e
# --- FIX: setup-netns.sh now renames every namespace's radio to this
# canonical name, so we no longer assume ns-corp specifically got the
# original "wlan0" (it might have gotten wlan1 or wlan2 depending on phy
# enumeration order at boot).
IFACE="wlan0"
NS="ns-corp"

# --- FIX: namespaces do not persist across reboots and are only created by
# setup-netns.sh, which must run before this script every boot. Running out
# of order previously failed with a bare "Cannot find device wlan0" - fail
# fast here with a message that says what to actually do about it.
if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (it must run once per boot before any start-*.sh script)." >&2
    exit 1
fi

if ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[*] Corp AP already running on $IFACE in $NS - nothing to do. (Use teardown.sh to reset.)"
    exit 0
fi

ip netns exec ns-corp ip link set "$IFACE" up
ip netns exec ns-corp ip addr replace 10.10.10.1/24 dev "$IFACE"
ip netns exec ns-corp hostapd -B /opt/eviltwin-lab/configs/hostapd-corp.conf \
    -f /opt/eviltwin-lab/logs/hostapd-corp.log

# --- FIX: `hostapd -B` forks to the background and returns success as soon
# as the fork happens - NOT once the AP is actually up. Verify it actually
# came up before declaring success, and surface the log if not.
sleep 1
if ! ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[!] hostapd did not bring $IFACE up as an AP. Last lines of its log:" >&2
    tail -n 20 /opt/eviltwin-lab/logs/hostapd-corp.log >&2 2>/dev/null || true
    exit 1
fi
