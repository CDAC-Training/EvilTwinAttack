#!/usr/bin/env bash
# Creates 3 network namespaces and assigns one hwsim phy to each, then
# renames that namespace's interface to a canonical "wlan0" so downstream
# scripts (start-corp-ap.sh, start-evil-twin.sh, start-victim.sh,
# capture-all.sh) never have to hardcode which literal wlanN ended up where.
# Runs on EVERY boot (namespaces do not persist across reboots).
set -euo pipefail

NS_ORDER=(ns-corp ns-eviltwin ns-victim)
CANONICAL_IFACE="wlan0"

# --- FIX: hwsim phys are created asynchronously by the kernel module at
# boot; without this wait, a race can leave phy0/1/2 briefly absent when
# this script runs very early, silently no-opping the 'iw phy ... set netns'
# calls below.
for _ in $(seq 1 20); do
    phy_count=$(iw phy 2>/dev/null | grep -c '^Wiphy' || true)
    [ "$phy_count" -ge 3 ] && break
    sleep 0.5
done

# Discover actual phy names dynamically - indices are NOT guaranteed to be
# 0/1/2; they increment monotonically across module reloads within a boot
# session and only reset to 0 on a fresh reboot.
mapfile -t PHYS < <(iw phy | awk '/^Wiphy/{print $2}')

if [ "${#PHYS[@]}" -lt 3 ]; then
    echo "[!] Expected 3 hwsim phys, found ${#PHYS[@]}: ${PHYS[*]:-none}" >&2
    echo "[!] Try: sudo modprobe -r mac80211_hwsim && sudo modprobe mac80211_hwsim radios=3" >&2
    exit 1
fi

# --- FIX (this is the hardcode bug): the interface name a phy owns
# (wlan0, wlan1, wlan2, ...) is assigned by the kernel in creation order
# and has NO guaranteed relationship to the phy enumeration order captured
# above - PHYS[0] is not necessarily "wlan0". The previous version of this
# script moved phys into namespaces without renaming, so every downstream
# script (start-corp-ap.sh, start-evil-twin.sh, start-victim.sh,
# capture-all.sh) had to hardcode a guess at which wlanN landed in which
# namespace - correct only when phy order happened to match interface
# creation order, and silently wrong otherwise. Build the real phy->iface
# map from `iw dev` instead of assuming it.
declare -A PHY_TO_IFACE
current_phy=""
while IFS= read -r line; do
    if [[ $line =~ ^phy#([0-9]+) ]]; then
        current_phy="phy${BASH_REMATCH[1]}"
    elif [[ $line =~ Interface[[:space:]]+([^[:space:]]+) ]]; then
        PHY_TO_IFACE["$current_phy"]="${BASH_REMATCH[1]}"
    fi
done < <(iw dev)

for ns in "${NS_ORDER[@]}"; do
    ip netns add "$ns" 2>/dev/null || true
done

for i in 0 1 2; do
    phy="${PHYS[$i]}"
    ns="${NS_ORDER[$i]}"
    iface="${PHY_TO_IFACE[$phy]:-}"

    if [ -z "$iface" ]; then
        echo "[!] Could not determine interface name for $phy - aborting" >&2
        exit 1
    fi

    iw phy "$phy" set netns name "$ns"

    # --- FIX: rename to the canonical name INSIDE the namespace, once it's
    # isolated there (no collision risk - each namespace holds exactly one
    # radio). Every downstream script can now rely on "$CANONICAL_IFACE"
    # regardless of which original wlanN this phy happened to own.
    ip netns exec "$ns" ip link set "$iface" down 2>/dev/null || true
    if [ "$iface" != "$CANONICAL_IFACE" ]; then
        ip netns exec "$ns" ip link set "$iface" name "$CANONICAL_IFACE"
    fi
done

for ns in "${NS_ORDER[@]}"; do
    ip netns exec "$ns" ip link set lo up
done

echo "[*] Namespaces ready (each with its radio renamed to ${CANONICAL_IFACE}):"
ip netns list
for ns in "${NS_ORDER[@]}"; do
    echo "  $ns:"
    ip netns exec "$ns" ip -brief link show "$CANONICAL_IFACE" 2>/dev/null | sed 's/^/    /'
done
