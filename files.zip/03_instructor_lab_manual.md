# Instructor Lab Manual — Evil Twin Attack Training Lab

**Course context:** UNIX/Linux System Administration / Cybersecurity Training
**Environment:** Proxmox-hosted Kali Linux, 25 linked-clone student VMs (`kali-student-01`
through `kali-student-25`). Each VM has two NICs: `eth0` on host-only `vmbr98`
(`10.99.99.1NN`, the Guacamole/RDP path) and `eth1` on campus `vmbr0`
(`140.158.130.NN`, for direct student RDP/SSH login). There is no `vmbr99`: all
wireless activity is simulated in-kernel with `mac80211_hwsim` inside each VM's
network namespaces and never crosses a Proxmox bridge.
**Estimated duration:** 3 hours (can split across two 90-minute sessions)

> **SECURITY (read before deploying):** `eth1` places each VM on a routable
> campus address while the accounts use `studentNN`/`studentNN` passwords with
> `sudo`. That credential scheme was justified only while every VM was
> host-only. Before relying on the campus path, put a firewall ACL in front of
> `140.158.130.0/24` restricting inbound RDP/SSH to classroom source ranges,
> and/or switch to SSH keys or stronger passwords. Also confirm the campus
> gateway/DNS/netmask in `01_golden_kali_setup.sh` §0 with campus networking,
> and ensure the gateway address does not fall within the student host range
> `.1–.25`.

---

## 1. Learning objectives

By the end of this lab, students will be able to:

1. Explain the evil-twin attack technique: SSID spoofing, rogue AP deployment,
   and why WiFi clients are vulnerable to it (no mutual authentication of the
   network to the client in the base 802.11 association process).
2. Stand up a rogue access point with `hostapd` that impersonates a
   legitimate SSID, and a supporting DHCP/DNS/captive-portal chain with
   `dnsmasq`.
3. Force a client off a legitimate AP and observe it reassociate to a rogue AP
   of matching SSID. **Note on fidelity:** this build demonstrates the
   *effect* of a deauthentication attack via `simulate-deauth.sh` rather than
   injecting spoofed deauth frames. Real injection requires a monitor-mode
   radio and `wmediumd` to bridge the per-namespace hwsim medium, neither of
   which is present here (see §5 Part 4 and §10). The distinction is itself a
   teaching point and is called out in the student answer key.
4. Capture and analyze 802.11 traffic in Wireshark/`tshark`/`aircrack-ng` to
   **detect** an evil twin from BSSID/channel/capability anomalies — i.e.,
   perform the defender's side of the same scenario.
5. Articulate mitigations: 802.11w (Protected Management Frames), WIPS,
   certificate-based EAP-TLS, and user training against auto-join behavior.
6. Operate entirely within the rules of engagement for an isolated,
   authorized lab environment and explain why the same actions are illegal
   outside such an environment.

## 2. Prerequisites

- Students should have completed (or be concurrently enrolled in) a UNIX/Linux
  fundamentals module covering `ip`, process management, and basic
  networking (DHCP, DNS).
- Familiarity with `iw`/`iwconfig` conceptually (lecture-level is sufficient;
  this lab is where they get hands-on).
- Each student accesses their own VM through Guacamole using a per-VM
  account: `studentNN` on `kali-student-NN` (e.g. `student07` on
  `kali-student-07`). There is no shared login — each account is created
  automatically on that VM's first boot by `firstboot-identity.sh`.
- **Credential scheme (matches the deployed `firstboot-identity.sh`):** each
  account's password is set **equal to its username** (`student07` /
  `student07`). This is a deliberate simplification that is acceptable *only*
  because these VMs sit on the isolated host-only `vmbr98` network with no
  route off-host; do not reuse the pattern anywhere with external exposure.
  There is **no forced password change** on first login. Each VM records its
  own credential line (hostname, username, password) in root-only
  `/root/student-credentials.txt` for your reference. Because the password is
  deterministic, you do not need to retrieve it per-VM to hand out — but the
  file remains the source of truth if you ever change the scheme.

## 3. Pre-lab instructor setup (do this before the session)

1. Build and generalize the golden image: run `01_golden_kali_setup.sh`,
   `02_generalize_for_cloning.sh`, and `03_configure_xrdp.sh` on VM 1000, then
   shut it down (do **not** reboot it first — see the warning printed at the
   end of the generalize script) and `qm template 1000`.
2. Confirm both bridges exist: `vmbr98` (host-only management) and `vmbr0`
   (campus). Narrow `vmbr98`'s `dnsmasq` pool so it doesn't overlap the static
   range `.101–.125` (see `deploy-clones.sh`'s pre-flight check, which refuses
   to run otherwise). Before building the golden image, set the campus
   parameters in `01_golden_kali_setup.sh` §0 (`CAMPUS_NET_PREFIX`,
   `CAMPUS_PREFIX_LEN`, `CAMPUS_GATEWAY`, `CAMPUS_DNS_1/2`) and confirm them
   with campus networking — a wrong gateway means no off-subnet login, and the
   `140.158.130.NN` addresses must be reserved so they don't collide with
   existing campus hosts.
   > **Architecture note:** all wireless traffic in this lab is simulated by
   > `mac80211_hwsim` *inside each VM*, isolated in three network namespaces —
   > it never leaves the VM or touches a Proxmox bridge. `vmbr99` (an "isolated
   > lab traffic" bridge from an earlier design) has been removed from
   > `deploy-clones.sh`; the second NIC is now `vmbr0` (campus) for direct
   > student login.
3. **Verify the golden image's hostapd/dnsmasq configs bind to `wlan0`.**
   The current `01_golden_kali_setup.sh` writes `interface=wlan0` into both
   eviltwin configs and ships the renamed-`wlan0` `setup-netns.sh`, so a
   freshly built image is already correct. This check exists to catch an
   *older* template built before that fix — a stale `interface=wlan1` causes
   `hostapd` to fail with `Could not read interface wlan1 flags: No such
   device`, affecting every clone. Confirm on the template (or a test clone)
   before mass deployment:
   ```bash
   grep -H '^interface=' /opt/eviltwin-lab/configs/hostapd-corp.conf \
                          /opt/eviltwin-lab/configs/hostapd-eviltwin.conf \
                          /opt/eviltwin-lab/configs/dnsmasq-eviltwin.conf
   # every line must read interface=wlan0
   ```
   If any read `wlan1`/`wlan2`, fix them in the golden image and re-template:
   ```bash
   sudo sed -i 's/^interface=.*/interface=wlan0/' \
       /opt/eviltwin-lab/configs/hostapd-eviltwin.conf \
       /opt/eviltwin-lab/configs/dnsmasq-eviltwin.conf
   ```
4. Deploy the clones by running `deploy-clones.sh` on the Proxmox host. This
   creates VMIDs `9101`–`9125` (`kali-student-01` through `kali-student-25`),
   assigns each a static `10.99.99.10N` address on `vmbr98`, and waits for
   `eviltwin-firstboot.service` to finish on each before reporting readiness.
5. **Create the 25 Guacamole connection profiles** — one per student,
   pointing at that VM's static `vmbr98` IP with the `studentNN` username and
   the matching `studentNN` password (see §9 for the full mapping). Because
   the password equals the username, these profiles can be fully
   pre-populated and bulk-imported; no per-student secret handoff is required.
6. Take a **fresh snapshot of each student VM** at this clean state
   (`qm snapshot 91NN clean-start`). This is the reset point between attempts
   and between class sections. Rolling back restores the whole VM to this
   state (including the `studentNN` password, which never changes) — there is
   no forced-change state to worry about.
7. Spot-check one student VM end-to-end using the student manual yourself.
   Before `setup-netns.sh`, `iw dev` should list `phy0/wlan0`, `phy1/wlan1`,
   `phy2/wlan2` in the default namespace; **after** `setup-netns.sh`, each of
   `ns-corp`/`ns-eviltwin`/`ns-victim` should show a single `wlan0` and the
   default namespace should show none. Confirm `/opt/eviltwin-lab/scripts/*.sh`
   are present and executable, and that both APs reach `type AP`.
8. Read out (or post) the **Rules of Engagement** banner from the student
   manual §2 before releasing students into the lab. Log attendance
   acknowledgment if your program requires it.

## 4. Session flow / timing

| Time | Activity |
|---|---|
| 0:00–0:15 | Briefing: evil twin concept, RoE, lab architecture overview |
| 0:15–0:35 | Part 1–2: environment verification, build Corporate AP |
| 0:35–1:00 | Part 3: build Evil Twin AP + captive portal |
| 1:00–1:20 | Part 4: victim baseline association + simulated-deauth roam |
| 1:20–1:45 | Part 5/6: joint packet capture across all three radios |
| 1:45–2:15 | Part 7: pcap analysis — identify the evil twin from the capture |
| 2:15–2:30 | Break |
| 2:30–2:50 | Part 8: credential-harvest review + defensive discussion |
| 2:50–3:00 | Review questions, submission, wrap-up |

> **Capture ordering (important):** the traffic students must analyze — the
> deauth frame, the roam, and the credential POST — is produced during Parts 5
> and 8. `capture-all.sh` (Part 6) must therefore be **started before** the
> Part 5 deauth, in a second terminal. The student manual's §3 "Recommended
> execution order" box lays this out; reinforce it verbally, as running the
> capture after the roam is the most common reason a student's pcap is missing
> the deauth frame.

## 5. Walkthrough answer key (mirrors student manual section numbers)

**Part 1 — Verification.** Before `setup-netns.sh`: `iw dev` lists
`phy0/wlan0`, `phy1/wlan1`, `phy2/wlan2` in the default namespace. If a student
sees only one or two, the hwsim module likely loaded with the wrong `radios=`
count — check `/etc/modprobe.d/mac80211_hwsim.conf` and
`lsmod | grep mac80211_hwsim`; recover with
`modprobe -r mac80211_hwsim && modprobe mac80211_hwsim radios=3`. After
`setup-netns.sh`, the three radios are moved into namespaces and each is
**renamed to `wlan0`**; the default namespace then has no wireless interface,
which is expected, not an error.

**Part 2 — Corporate AP.** After `start-corp-ap.sh`, `ip netns exec ns-corp
iw dev wlan0 info` should show `type AP` and `ssid CorpNet-Secure`. The
`start-*.sh` scripts now bring the interface up, verify `type AP` after
launch, and print the `hostapd` log tail on failure — so a student who hand-
runs commands out of order (e.g. `hostapd` before `ip link set wlan0 up`) will
get a clear diagnostic rather than a silent failure.

**Part 3 — Evil Twin.** `ip netns exec ns-eviltwin iw dev wlan0 info` should
also show `type AP` / `ssid CorpNet-Secure`. Key teaching point: the twin's
BSSID **differs** from the legit AP's (`hostapd` uses the radio's own MAC
automatically). Remind students *not* to hand-set a matching BSSID — full MAC
cloning is a further escalation worth a class discussion but not required for
the base exercise. The twin runs **open** (`wpa=0`) so its traffic is
interceptable in cleartext; corp runs WPA2.

**Part 4 — Baseline association, then simulated deauth + roam.**

*Baseline.* Corp is WPA2, so the victim cannot join it with a bare
`iw connect` (which handles only open/WEP). The student uses `wpa_supplicant`
with the corporate BSSID pinned, so it associates to the legitimate AP and not
the twin (both share the SSID). Confirm the `iw dev wlan0 link` line shows the
corp BSSID and its channel (6 / 2437 MHz).

*Why not `aireplay-ng`.* A real deauth attack injects spoofed frames from a
**monitor-mode** radio impersonating the AP's BSSID. This topology commits all
three radios to fixed roles (two AP masters, one client), leaving none free
for monitor mode, and there is **no `wmediumd`** to carry injected frames
between namespaces. An `aireplay-ng` attempt here hangs on "Waiting for beacon
frame" (wrong channel / no monitor radio) or fails with `SIOCSIWMODE: Device
or resource busy` when it tries to flip a busy AP interface to monitor mode.
`simulate-deauth.sh` therefore reproduces the *effect*: it stops the victim's
`wpa_supplicant` and issues a station-initiated disconnect. mac80211 still
emits a genuine deauthentication management frame (type 0 / subtype `0x0c`) as
the station leaves, so a real deauth frame is present in `victim.pcap` for
analysis — the only difference from a live attack is that the frame is
station-sourced rather than attacker-spoofed (see the Q3/Q5 instructor note in
the student answer key).

*Roam.* After the simulated deauth, the student reassociates the victim to the
**evil twin's** BSSID with `iw connect CorpNet-Secure <EVIL_BSSID>` (the twin
is open, so `iw connect` is the correct tool). Pinning the BSSID makes the roam
deterministic; without it the kernel would pick between two identical-SSID APs
by signal, which is non-deterministic under hwsim.

**Part 6 — Capture.** `capture-all.sh` captures on `wlan0` in each namespace
and produces `corp.pcap`, `eviltwin.pcap`, `victim.pcap` under
`/opt/eviltwin-lab/captures/`. It must be run with `sudo` and after
`setup-netns.sh` (it now reports which of those two preconditions is unmet
rather than a generic error). Students `mergecap -w combined.pcap corp.pcap
eviltwin.pcap victim.pcap` for joint analysis.

**Part 7 — Analysis.** Expected findings students must report (see student
manual Part 7 questions for the graded version):
- Two beacon-emitting BSSIDs advertising the identical SSID `CorpNet-Secure`.
- Differing channel (6 vs 11) and differing capability bits — the RSN IE /
  privacy bit is present on the legitimate AP's beacon and absent on the
  twin's (open network).
- A deauthentication frame (subtype `0x0c`) immediately preceding the client's
  reassociation to the second BSSID. In this build it is a single
  station-initiated deauth rather than an attacker-injected burst; the frame
  type/subtype students identify is identical.
- Cleartext HTTP POST containing harvested credentials once associated to the
  twin (visible in `victim.pcap`/`eviltwin.pcap`, with no cleartext equivalent
  on `corp.pcap`).

**Part 8 — Credential harvest / defense discussion.** Show
`/opt/eviltwin-lab/logs/harvested_creds.log` on the evil-twin side to close
the loop, then pivot to mitigations (§6 below) as a discussion, not a
hands-on step.

## 6. Discussion: defenses (for the debrief)

- **802.11w / PMF** (Protected Management Frames) — cryptographically protects
  deauth/disassoc frames, defeating the *spoofed-deauth* variant of this
  attack (an attacker without the session key cannot forge an accepted deauth).
  Note for precision: PMF protects against forged frames; it would not prevent
  a legitimate station from choosing to leave, which is what this build's
  simulation actually does. In a real attack, PMF is the direct mitigation for
  the injection step.
- **EAP-TLS / certificate-pinned enterprise WiFi** — a client validating the
  RADIUS server's certificate will refuse to associate to a twin that can't
  present a valid cert, regardless of matching SSID (and BSSID).
- **WIPS (Wireless Intrusion Prevention Systems)** — detect duplicate
  SSID/differing BSSID pairs automatically and can send targeted deauth
  against the rogue AP.
- **User-facing controls** — disabling auto-join for open networks, and
  training users to notice unexpected re-authentication prompts.

## 7. Grading rubric (suggested, 100 pts)

| Component | Points |
|---|---|
| Environment stood up correctly (3 namespaces, both APs at `type AP`) | 15 |
| Simulated deauth + roam to the twin demonstrated and captured | 15 |
| Joint pcap submitted, correctly merged | 10 |
| Correct identification of evil-twin indicators in pcap (Part 7 Qs) | 30 |
| Defense/mitigation short answer quality | 15 |
| Adherence to Rules of Engagement / lab hygiene (clean teardown) | 15 |

## 8. Troubleshooting quick reference

| Symptom | Likely cause | Fix |
|---|---|---|
| `iw dev` shows no interfaces *before* `setup-netns.sh` | hwsim module not loaded | `modprobe mac80211_hwsim radios=3` |
| `iw dev` shows no interfaces *after* `setup-netns.sh` | expected — radios moved into namespaces | not an error; use `ip netns exec ns-<role> iw dev` |
| `start-*.sh` / `capture-all.sh` reports `wlan0 not found in ns-...` | ran without `sudo`, or `setup-netns.sh` not run this boot | run with `sudo`; run `setup-netns.sh` once per boot first |
| `hostapd` fails: `Could not read interface wlan1 ... No such device` | stale `interface=wlan1` in the config (pre-rename naming) | `sed -i 's/^interface=.*/interface=wlan0/'` the config; fix in the golden image so clones inherit it (§3 step 3) |
| `hostapd` "starts" but interface stays `type managed` | `hostapd -B` forked then the daemon died; script now prints its log tail | read the printed `hostapd-*.log` tail; usual causes are the `interface=` mismatch above or a busy interface |
| Evil twin has no DHCP clients | `dnsmasq` bound to wrong interface, or already running from a previous attempt | `pkill dnsmasq`; confirm `dnsmasq-eviltwin.conf` `interface=wlan0` and `dhcp-range` matches the `10.10.11.0/24` subnet |
| Victim never roams to the twin | reassociation didn't pin the twin BSSID, or both APs share the SSID and it landed on corp | reconnect with the explicit `EVIL_BSSID`: `iw dev wlan0 connect CorpNet-Secure <EVIL_BSSID>` |
| Victim can't join corp at baseline | used `iw connect` against WPA2 (unsupported) | use the `wpa_supplicant` step from student manual Part 4 |
| `aireplay-ng` hangs on "Waiting for beacon frame" | no monitor radio / no `wmediumd` — real injection unsupported here | use `simulate-deauth.sh` (by design); do not attempt live injection |
| Captive portal doesn't log creds | `php -S` not running, or wrong doc root | confirm `start-evil-twin.sh`'s background `php -S` process is alive |
| Student VM "dirty" after a failed attempt | processes/namespaces left over | `teardown.sh` then `setup-netns.sh` to restart cleanly, or restore `clean-start` snapshot |
| Two students report the same IP/hostname | `deploy-clones.sh` pre-flight DHCP-pool check skipped, or clones made by hand | re-run the pre-flight against `/etc/dnsmasq.d/vmbr98-lab-mgmt.conf`; never clone the template by hand without setting `-smbios1` per the script |
| Student can't reach `140.158.130.NN` (campus login) | wrong `CAMPUS_GATEWAY`, IP not reserved on campus, or ACL blocking; or `eth1` didn't map to `vmbr0` in the guest | verify `01_...sh` §0 values; on the VM check `ip -4 addr show eth1` and `ip route` (default via campus gw); confirm net1=`vmbr0` in `qm config <vmid>` |
| `eth1` has no address on a clone | `20-eth1.network.template` missing at build, or firstboot didn't run | check `journalctl -u eviltwin-firstboot`; confirm the template exists in the golden image; re-render: `sed "s/__NN__/<n>/" 20-eth1.network.template > 20-eth1.network && networkctl reload` |

## 9. Student account / connection reference (Guacamole + direct campus login)

Each VM's account is created automatically on first boot — there is no shared
login. The password is set equal to the username (`studentNN` / `studentNN`)
and does not change; each VM also records its credential line in root-only
`/root/student-credentials.txt`. Students can reach their VM two ways: through
Guacamole (which connects over the host-only `vmbr98` IP), or by RDP/SSH
directly to the campus `vmbr0` IP. Use this table for both:

| Student # | Hostname | Username | Password | vmbr98 IP (Guacamole) | Campus IP (direct login) | VMID |
|---|---|---|---|---|---|---|
| 01 | `kali-student-01` | `student01` | `student01` | `10.99.99.101` | `140.158.130.1` | 9101 |
| 02 | `kali-student-02` | `student02` | `student02` | `10.99.99.102` | `140.158.130.2` | 9102 |
| … | … | … | … | … | … | … |
| NN | `kali-student-NN` | `studentNN` | `studentNN` | `10.99.99.1NN` | `140.158.130.NN` | 91NN |
| 25 | `kali-student-25` | `student25` | `student25` | `10.99.99.125` | `140.158.130.25` | 9125 |

> Note the two host-octet schemes differ: the management IP is `100 + N`
> (`10.99.99.101`…`.125`), while the campus IP is `N` itself
> (`140.158.130.1`…`.25`), per the requested "last two digits of the hostname"
> mapping. Watch the low campus addresses against your gateway: if
> `CAMPUS_GATEWAY` is `.1`, it collides with `student01` — reserve a gateway
> outside `.1–.25` or renumber.

The pattern is mechanical, so this table can be generated rather than typed:

```bash
for i in $(seq -w 1 25); do
    printf 'student%s | kali-student-%s | mgmt 10.99.99.1%s | campus 140.158.130.%s | 91%s\n' "$i" "$i" "$i" "$((10#$i))" "$i"
done
```

If your Guacamole deployment supports bulk import (CSV or REST API), use this
loop's output as the basis for a script rather than creating 25 profiles by
hand in the UI.
