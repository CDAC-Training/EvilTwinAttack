#!/usr/bin/env bash
set -e
OUT=/opt/eviltwin-lab/captures
# --- FIX: setup-netns.sh now renames every namespace's radio to this
# canonical name, so we no longer assume ns-corp/ns-eviltwin/ns-victim got
# wlan0/wlan1/wlan2 respectively (that mapping depended on phy enumeration
# order at boot and was not guaranteed).
IFACE="wlan0"

# --- FIX: distinguish the three real failure modes instead of reporting a
# misleading "wlan0 not found" for all of them. `ip netns exec` needs root,
# and when run as a normal user it fails the interface check silently, which
# previously looked identical to the namespace/interface genuinely missing.
if [ "$(id -u)" -ne 0 ]; then
    echo "[!] This script must be run as root. Re-run: sudo $0" >&2
    exit 1
fi

for ns in ns-corp ns-eviltwin ns-victim; do
    if ! ip netns list | grep -qw "$ns"; then
        echo "[!] Namespace $ns does not exist. Run setup-netns.sh first (it must run once per boot before any start-*.sh/capture-all.sh script)." >&2
        exit 1
    fi
    if ! ip netns exec "$ns" ip link show "$IFACE" &>/dev/null; then
        echo "[!] $IFACE not found in $ns. Run setup-netns.sh first (it must run once per boot before any start-*.sh/capture-all.sh script)." >&2
        exit 1
    fi
done

mkdir -p "$OUT"
ip netns exec ns-corp     tcpdump -i "$IFACE" -w "$OUT/corp.pcap"      -U &
ip netns exec ns-eviltwin tcpdump -i "$IFACE" -w "$OUT/eviltwin.pcap"  -U &
ip netns exec ns-victim   tcpdump -i "$IFACE" -w "$OUT/victim.pcap"    -U &
echo "Capturing on $IFACE in ns-corp/ns-eviltwin/ns-victim. Ctrl-C to stop, then mergecap the three files."
wait
