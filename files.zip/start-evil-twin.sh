#!/usr/bin/env bash
set -e
# --- FIX: setup-netns.sh now renames every namespace's radio to this
# canonical name, so we no longer assume ns-eviltwin specifically got the
# original "wlan1" (it might have gotten wlan0 or wlan2 depending on phy
# enumeration order at boot).
IFACE="wlan0"
NS="ns-eviltwin"

# --- FIX: namespaces do not persist across reboots and are only created by
# setup-netns.sh, which must run before this script every boot. Running out
# of order previously failed with a bare "Cannot find device wlan0" - fail
# fast here with a message that says what to actually do about it.
if ! ip netns exec "$NS" ip link show "$IFACE" &>/dev/null; then
    echo "[!] $IFACE not found in $NS. Run setup-netns.sh first (it must run once per boot before any start-*.sh script)." >&2
    exit 1
fi

if ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[*] Evil twin AP already running on $IFACE in $NS - nothing to do. (Use teardown.sh to reset.)"
    exit 0
fi

ip netns exec ns-eviltwin ip link set "$IFACE" up
ip netns exec ns-eviltwin ip addr replace 10.10.11.1/24 dev "$IFACE"
ip netns exec ns-eviltwin hostapd -B /opt/eviltwin-lab/configs/hostapd-eviltwin.conf \
    -f /opt/eviltwin-lab/logs/hostapd-eviltwin.log

# --- FIX: `hostapd -B` forks to the background and returns success as soon
# as the fork happens - NOT once the AP is actually up. A config/driver
# failure in the daemonized child (wrong driver, interface already busy,
# bad hwmode, etc.) previously went completely unnoticed: the script kept
# going, dnsmasq/php started against an AP that was never actually
# broadcasting, and the interface silently stayed "type managed" instead of
# "type AP" (exactly what showed up when checking manually). Verify it
# actually came up before proceeding, and surface the log if not.
sleep 1
if ! ip netns exec "$NS" iw dev "$IFACE" info 2>/dev/null | grep -q "type AP"; then
    echo "[!] hostapd did not bring $IFACE up as an AP. Last lines of its log:" >&2
    tail -n 20 /opt/eviltwin-lab/logs/hostapd-eviltwin.log >&2 2>/dev/null || true
    exit 1
fi

ip netns exec ns-eviltwin dnsmasq -C /opt/eviltwin-lab/configs/dnsmasq-eviltwin.conf \
    --log-facility=/opt/eviltwin-lab/logs/dnsmasq-eviltwin.log
ip netns exec ns-eviltwin php -S 10.10.11.1:80 -t /opt/eviltwin-lab/portal &
